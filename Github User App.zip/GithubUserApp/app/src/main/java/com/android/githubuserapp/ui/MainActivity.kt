package com.android.githubuserapp.ui

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.githubuserapp.R
import com.android.githubuserapp.adapter.UserAdapter
import com.android.githubuserapp.model.User
import org.json.JSONObject
import java.util.*
import kotlin.collections.ArrayList

class MainActivity : AppCompatActivity(), SearchView.OnQueryTextListener {

    private lateinit var toolbar: Toolbar
    private lateinit var rv: RecyclerView
    private var list: ArrayList<User> = arrayListOf()
    private var tempList: ArrayList<User> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        rv = findViewById(R.id.rv_github_user)
        rv.setHasFixedSize(true)
        val searchView: SearchView = findViewById(R.id.item_search)
        searchView.queryHint = "cari nama user.."
        searchView.setOnQueryTextListener(this)

        addItem()
        showRecycler()
    }

//    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
//        menuInflater.inflate(R.menu.item_menu, menu)
//        val item: MenuItem? = menu?.findItem(R.id.menu_item_search)
//        val searchView: SearchView = item?.actionView as SearchView
//        searchView.queryHint = "cari nama user..."
//
//        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
//            override fun onQueryTextSubmit(query: String?): Boolean {
//                return false
//            }
//
//            override fun onQueryTextChange(newText: String?): Boolean {
//                tempList.clear()
//                val searchText = newText?.toLowerCase(Locale.getDefault())
//                if (searchText?.isNotEmpty() == true) {
//                    list.forEach {
//                        if (it.name.toLowerCase(Locale.getDefault()).contains(searchText)) {
//                            tempList.add(it)
//                        }
//                    }
//                    rv.adapter?.notifyDataSetChanged()
//                } else {
//                    tempList.clear()
//                    tempList.addAll(list)
//                    rv.adapter?.notifyDataSetChanged()
//                }
//                return true
//            }
//        })
//        return super.onCreateOptionsMenu(menu)
//    }

    private fun showRecycler() {
        rv.layoutManager = LinearLayoutManager(this)
        val adapter = UserAdapter(tempList)
        rv.adapter = adapter

        adapter.setOnItemClickCallBack(object : UserAdapter.OnItemClickCallBack {
            override fun onItemClicked(data: User) {
                Toast.makeText(this@MainActivity, data.name, Toast.LENGTH_SHORT).show()
                val intent = Intent(this@MainActivity, DetailActivity::class.java).apply {
                    putExtra(DetailActivity.EXTRA_USER, data)
                }
                startActivity(intent)
            }
        })
    }

    private fun addItem(): ArrayList<User> {
        try {
            val jsonObject = JSONObject(loadJson())
            val jsonArray = jsonObject.getJSONArray("users")
            for (i in 0 until jsonArray.length()) {
                val dataObject = jsonArray.getJSONObject(i)
                val avatar = resources.getIdentifier(
                    dataObject.getString("avatar"),
                    "drawable", packageName
                )
                val company = dataObject.getString("company")
                val follower = dataObject.getInt("follower")
                val following = dataObject.getInt("following")
                val location = dataObject.getString("location")
                val name = dataObject.getString("name")
                val repository = dataObject.getInt("repository")
                val username = dataObject.getString("username")
                val user =
                    User(avatar, company, follower, following, location, name, repository, username)
                list.add(user)
                tempList.add(user)
            }
        } catch (e: Exception) {
            Log.d(TAG, "Failed addItem: ${e.stackTrace}")
        }
        return list
    }

    private fun loadJson(): String {
        var json: String? = ""
        try {
            json = this.resources.openRawResource(R.raw.githubuser).bufferedReader()
                .use { it.readText() }
        } catch (e: Exception) {
            Log.d(TAG, "Failed loadJson: ${e.stackTrace}")
        }
        return json.toString()
    }

    override fun onQueryTextSubmit(query: String?): Boolean {
        return false
    }

    override fun onQueryTextChange(newText: String?): Boolean {
        tempList.clear()
        val searchText = newText?.toLowerCase(Locale.getDefault())
        if (searchText?.isNotEmpty() == true) {
            list.forEach {
                if (it.name.toLowerCase(Locale.getDefault()).contains(searchText)) {
                    tempList.add(it)
                }
            }
            rv.adapter?.notifyDataSetChanged()
        } else {
            tempList.clear()
            tempList.addAll(list)
            rv.adapter?.notifyDataSetChanged()
        }
        return false
    }

}