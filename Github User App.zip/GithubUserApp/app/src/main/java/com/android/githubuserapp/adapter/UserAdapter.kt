package com.android.githubuserapp.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.android.githubuserapp.R
import com.android.githubuserapp.model.User
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class UserAdapter(private var users: ArrayList<User>) :
    RecyclerView.Adapter<UserAdapter.ItemViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallBack

    fun setOnItemClickCallBack(onItemClickCallBack: OnItemClickCallBack) {
        this.onItemClickCallback = onItemClickCallBack
    }

    class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        private val tvName: TextView = itemView.findViewById(R.id.tv_item_name)
        private val tvCompany: TextView = itemView.findViewById(R.id.tv_item_company)
        private val imgAvatar: ImageView = itemView.findViewById(R.id.img_item_cover)

        internal fun bind(user: User) {
            Glide.with(itemView.context)
                .load(user.avatar)
                .apply(RequestOptions().override(80, 80))
                .error(R.drawable.ic_launcher_background)
                .into(imgAvatar)

            tvName.text = user.name
            tvCompany.text = user.company
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        return ItemViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.item_row_github_user, parent, false)
        )
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val user = users[position]
        holder.bind(user)
        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(users[position]) }
    }

    override fun getItemCount(): Int = users.size

    interface OnItemClickCallBack {
        fun onItemClicked(data: User)
    }

}