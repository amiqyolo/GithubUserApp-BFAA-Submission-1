package com.android.githubuserapp.ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.animation.AccelerateInterpolator
import android.widget.TextView
import com.airbnb.lottie.LottieAnimationView
import com.android.githubuserapp.R

class SplashActivity : AppCompatActivity() {

    private lateinit var lottieAnimationView: LottieAnimationView
    private lateinit var progressBar: LottieAnimationView
    private lateinit var tvText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        lottieAnimationView = findViewById(R.id.lottie)
        progressBar = findViewById(R.id.progress_bar)
        tvText = findViewById(R.id.tv_text)

        initItemAnimate()

        Handler(mainLooper).postDelayed({
            startActivity(Intent(this@SplashActivity, MainActivity::class.java))
            finish()
        }, 3000L)
    }

    private fun initItemAnimate() {
        tvText.animate().alpha(1f).alpha(0f).setDuration(3000L).interpolator =
            AccelerateInterpolator()
        lottieAnimationView.animate().translationY(-3000f).setDuration(1000L).startDelay = 3000L
        progressBar.animate().translationY(3000f).setDuration(1000L).startDelay = 3000L
    }
}