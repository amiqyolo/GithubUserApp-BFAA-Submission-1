package com.android.githubuserapp.ui

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.android.githubuserapp.R
import com.android.githubuserapp.model.User
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class DetailActivity : AppCompatActivity() {

    private lateinit var user: User
    private lateinit var ivAvatar: ImageView
    private lateinit var tvName: TextView
    private lateinit var tvUsername: TextView
    private lateinit var tvFollower: TextView
    private lateinit var tvFollowing: TextView
    private lateinit var tvRepository: TextView
    private lateinit var tvCompany: TextView
    private lateinit var tvLocation: TextView

    companion object {
        const val EXTRA_USER = "DetailActivity.EXTRA_USER"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        ivAvatar = findViewById(R.id.iv_detail_avatar)
        tvName = findViewById(R.id.tv_detail_name)
        tvUsername = findViewById(R.id.tv_detail_username)
        tvFollower = findViewById(R.id.tv_detail_follower)
        tvFollowing = findViewById(R.id.tv_detail_following)
        tvRepository = findViewById(R.id.tv_detail_repository)
        tvCompany = findViewById(R.id.tv_detail_company)
        tvLocation = findViewById(R.id.tv_detail_location)

        user = intent.getParcelableExtra(EXTRA_USER)!!

        setToolbar()
        bind(this, user)
    }

    private fun setToolbar() {
        if (supportActionBar != null) {
            supportActionBar?.apply {
                setDisplayHomeAsUpEnabled(true)
                setDisplayShowHomeEnabled(true)
                title = "Info Profile"
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }

    private fun bind(context: Context, user: User) {
        tvName.text = user.name
        tvUsername.text = user.username
        tvFollower.text = user.follower.toString()
        tvFollowing.text = user.following.toString()
        tvRepository.text = user.repository.toString()
        tvCompany.text = user.company
        tvLocation.text = user.location

        Glide.with(context)
            .load(user.avatar)
            .apply(
                RequestOptions()
                    .circleCrop()
                    .override(120, 120)
            )
            .into(ivAvatar)
    }

}